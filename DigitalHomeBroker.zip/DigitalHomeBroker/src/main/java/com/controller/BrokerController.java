package com.controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;


import com.model.Home;
import com.service.BrokerService;

//use appropriate annotation to configure BrokerController as Controller
public class BrokerController {
	
	//Use appropriate annotation above this property
	private BrokerService service;
	
	
	//invoke the service class - searchHome method.
	public String searchHome(@ModelAttribute("homeBean") Home homeBean, BindingResult result,
			ModelMap model) {
		
		//fill the code
		return null;
	}
}
