package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.MovieRespository;
import com.example.entity.Movie;

@Service
public class TheaterService {
	
	@Autowired
	MovieRespository movieRespository;
	
	public void saveMovie(Movie movie) {
		movieRespository.save(movie);
	}
}
