package com.example.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.Movie;

public interface MovieRespository extends JpaRepository<Movie, Integer> {

}
