package com.anushree.spring.SpringDataJPA4.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anushree.spring.SpringDataJPA4.entity.Author;

public interface AuthorRepository extends JpaRepository<Author, Integer> {

}
