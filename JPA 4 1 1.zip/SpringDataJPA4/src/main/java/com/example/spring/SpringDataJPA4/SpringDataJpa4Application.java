package com.anushree.spring.SpringDataJPA4;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.anushree.spring.SpringDataJPA4.entity.Author;
import com.anushree.spring.SpringDataJPA4.entity.Book;
import com.anushree.spring.SpringDataJPA4.service.LibraryService;

@SpringBootApplication
@ComponentScan("com.anushree.spring.SpringDataJPA4")
public class SpringDataJpa4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpa4Application.class, args);
	}
	
	@Bean
	public CommandLineRunner demo (LibraryService service) {
		return (args) -> {
			
	Author author = new Author("John");
	author = service.saveAuthor (author);
	Book bookl = new Book("Core Java", "Technology");
	bookl.setAuthor (author);
	bookl = service.saveBook (bookl);
	
	Book book2 = new Book ("SpringBoot", "Technology");
	book2.setAuthor (author);
	book2 = service.saveBook (book2);
	
	// get all authors
	System.out.println(service.getAllAuthors ());
	
	// get book by given book id
	System.out.println(service.getBookByBookId(2));
	
	// get all books of given author id
	System.out.println(service.getAllBooksByAuthorId(1));
	};
 }

}
