package com.anushree.spring.SpringDataJPA4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anushree.spring.SpringDataJPA4.dao.AuthorRepository;
import com.anushree.spring.SpringDataJPA4.dao.BookRepository;
import com.anushree.spring.SpringDataJPA4.entity.Author;
import com.anushree.spring.SpringDataJPA4.entity.Book;

@Service
public class LibraryService {

	// Autowire AuthorRepository and BookRepository objects;
	
    @Autowired
    private AuthorRepository authorRepository;

    @Autowired
    private BookRepository bookRepository;
	
	public Author saveAuthor (Author author) {
		return authorRepository.save(author);
	}
	
	public Book saveBook (Book book) {
	return bookRepository.save(book);
	}
	
	public List<Author> getAllAuthors () {
		return authorRepository.findAll();
	}
	
	public Book getBookByBookId(int bookId) {
	return bookRepository.findByBookId(bookId);
	}
	
	public List<Book> getAllBooksByAuthorId(int authorId) {
		return bookRepository.findAllBooksByAuthorId(authorId);
	}
	
}
