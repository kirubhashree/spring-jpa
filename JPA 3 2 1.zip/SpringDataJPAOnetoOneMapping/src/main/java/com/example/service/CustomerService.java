package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.AddressRepository;
import com.example.dao.CustomerRepository;
import com.example.entity.Address;
import com.example.entity.Customer;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired 
	AddressRepository addressRepository;
	
	public void saveCustomer(Customer customer, Address address) {
		
		Address savedAddress = addressRepository.save(address);
		
		customer.setAddress(savedAddress);
		
		customerRepository.save(customer);
		
	}
	
	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}
	
	public List<Customer> getAllCustomersFromCity(String city) {
		return customerRepository.findByCity(city);
	}

}
