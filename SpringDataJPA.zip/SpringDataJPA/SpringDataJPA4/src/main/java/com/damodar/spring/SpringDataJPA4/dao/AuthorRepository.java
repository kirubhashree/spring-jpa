package com.damodar.spring.SpringDataJPA4.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.damodar.spring.SpringDataJPA4.entity.Author;

public interface AuthorRepository extends JpaRepository<Author, Integer> {

}
