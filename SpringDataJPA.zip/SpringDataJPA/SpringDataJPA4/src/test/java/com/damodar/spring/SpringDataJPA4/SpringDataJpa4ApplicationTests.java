package com.damodar.spring.SpringDataJPA4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpa4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
