package com.damodar.spring.SpringDataJPA3.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.damodar.spring.SpringDataJPA3.dao.AddressRepository;
import com.damodar.spring.SpringDataJPA3.dao.CustomerRepository;
import com.damodar.spring.SpringDataJPA3.entity.Address;
import com.damodar.spring.SpringDataJPA3.entity.Customer;

@Service
public class CustomerService {

	// Autowire CustomerRepository and AddressRepository objects;
	
	 @Autowired
	 private CustomerRepository customerRepository;

	 @Autowired
	 private AddressRepository addressRepository;
	
	public void saveCustomer (Customer customer, Address address) {
		 // Save the address object
        addressRepository.save(address);

        // Set the address of the customer object with the saved address object
        customer.setAddress(address);

        // Save the customer object
        customerRepository.save(customer);
	}
	public List<Customer> getAllCustomers () {
		
		return customerRepository.findAll();
	}
	
	public List<Customer> getAllCustomersFromCity (String city) {
		
		return customerRepository.findByCity(city);
	}
}
