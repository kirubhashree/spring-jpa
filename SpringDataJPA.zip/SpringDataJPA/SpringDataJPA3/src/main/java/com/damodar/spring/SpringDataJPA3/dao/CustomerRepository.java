package com.damodar.spring.SpringDataJPA3.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.damodar.spring.SpringDataJPA3.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer ,Integer> {

	//add Query
	@Query("SELECT c FROM Customer c WHERE c.address.city = :city")
    List<Customer> findByCity(@Param("city") String city);
}
