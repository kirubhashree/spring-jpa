package com.damodar.spring.SpringDataJPA1;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.damodar.spring.SpringDataJPA1.model.Customer;
import com.damodar.spring.SpringDataJPA1.service.CustomerService;

@SpringBootApplication
@ComponentScan("com.damodar.spring.SpringDataJPA1")
public class SpringDataJpa1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpa1Application.class, args);
	}
	
	@Bean
	public CommandLineRunner demo (CustomerService service) {
	return (args) -> {
	
	service.saveCustomer (new Customer("Jack", "8234567890", "Pune"));
	service.saveCustomer (new Customer("Sonu", "9934565590", "Chennai"));
	service.saveCustomer (new Customer("Mitali", "7134567890", "Bangalore"));
	
	//update customer mobile number, whose id is 5 System.out.println("Updated Customer:");
	System.out.println(service.updateCustomer (5, "9534567890"));

	//fetch all customers
	System.out.println(service.findAllCustomers());
	
	//delete customer with id 5
	
	service.deleteCustomer (5);
 };
}

}
