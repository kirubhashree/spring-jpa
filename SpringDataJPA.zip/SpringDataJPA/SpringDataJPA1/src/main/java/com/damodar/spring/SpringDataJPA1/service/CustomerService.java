package com.damodar.spring.SpringDataJPA1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.damodar.spring.SpringDataJPA1.dao.CustomerRepository;
import com.damodar.spring.SpringDataJPA1.model.Customer;

@Service
public class CustomerService {

	
	@Autowired
	private CustomerRepository customerRepository;
	
	public int saveCustomer(Customer customer) {
		
		Customer savedCustomer = customerRepository.save(customer);		
		return savedCustomer.getId();
	}
	
	public List<Customer> findAllCustomers() {
		
		return customerRepository.findAll();
	}
	
	public Optional<Customer> updateCustomer(int customerId,String newMobileNumber){
		
		Optional<Customer> optionalCustomer = customerRepository.findById(customerId);
		if (optionalCustomer.isPresent()) {
			Customer customer = optionalCustomer.get();
			customer.setMobileNumber(newMobileNumber);
			customerRepository.save(customer);
		}
		return optionalCustomer;	}
	
	public void deleteCustomer(int customerId) {
		customerRepository.deleteById(customerId);
	}
	
}
