package com.damodar.spring.SpringDataJPA5.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.damodar.spring.SpringDataJPA5.entity.Movie;

public interface MovieRepository extends JpaRepository<Movie, Integer> {

}
