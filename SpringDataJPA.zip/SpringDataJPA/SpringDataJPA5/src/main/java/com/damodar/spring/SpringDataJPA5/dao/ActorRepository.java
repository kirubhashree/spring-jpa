package com.damodar.spring.SpringDataJPA5.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.damodar.spring.SpringDataJPA5.entity.Actor;

public interface ActorRepository extends JpaRepository<Actor, Integer> {

}
