package com.damodar.spring.SpringDataJPA5.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.damodar.spring.SpringDataJPA5.dao.MovieRepository;
import com.damodar.spring.SpringDataJPA5.entity.Movie;

@Service
public class TheaterService {

	@Autowired
	private MovieRepository movieRepository;
	
	public void saveMovie(Movie movie) {
		
		movieRepository.save(movie);
	}
	
}
