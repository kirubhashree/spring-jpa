package com.damodar.spring.SpringDataJPA2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpa2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
