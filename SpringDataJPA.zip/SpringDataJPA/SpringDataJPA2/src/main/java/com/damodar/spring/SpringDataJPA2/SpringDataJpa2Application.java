package com.damodar.spring.SpringDataJPA2;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.damodar.spring.SpringDataJPA2.entity.Employee;
import com.damodar.spring.SpringDataJPA2.service.EmployeeService;

@SpringBootApplication
@ComponentScan("com.damodar.spring.SpringDataJPA2")
public class SpringDataJpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpa2Application.class, args);
	}
	
	@Bean
	public CommandLineRunner demo (EmployeeService service) {
	return (args) -> {
	// save a few Employees
	service.saveEmployee (new Employee ("Suman", 120000, "Pune", "Consultant"));
	service.saveEmployee (new Employee ("Ajay", 25000, "Bangalore", "Trainee"));
	service.saveEmployee (new Employee ("Sree", 95000, "Chennai", "Manager"));
	service.saveEmployee (new Employee ("Anjali", 80000, "Chennai", "Associate Consultant"));
	service.saveEmployee (new Employee ("Smith", 90000, "Bangalore", "Manager"));
	
	// Find all employees whose name starts with 'S'
	System.out.println(service.findEmployeesByNameLike("S%"));
	
	// Find all employees having salary greater than 50000
    System.out.println(service.findEmployeesBySalaryGreaterThanEqual(50000.00));
	
	// update base location to 'Mumbai'of employee having id 23
	System.out.println(service.updateBaseLocation (3, "Mumbai") + "record/s updated");
	
	// find employees by base location, display in descending order of their name
	System.out.println(service.findByLocationOrderByName("Bangalore"));
	
	// find employees by given base location and designation
	System.out.println(service.findByBaseLocationAndDesignation("Chennai", "Manager"));
	
	// find employees having salary between given range
	System.out.println(service.findEmployeesBySalaryBetween (25000, 90000));
	
	};
  }
}
