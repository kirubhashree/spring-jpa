package com.damodar.spring.SpringDataJPA2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.damodar.spring.SpringDataJPA2.dao.EmployeeRepository;
import com.damodar.spring.SpringDataJPA2.entity.Employee;

@Service
public class EmployeeService {

	//Autowire EmployeeRepository object
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public int saveEmployee(Employee emp) {
		Employee savedEmployee = employeeRepository.save(emp);
		return savedEmployee.getEmpId();
	}
	
	public List<Employee> findEmployeesByNameLike(String pattern) {
		return employeeRepository.findByNameLike(pattern);
	}
	
	public List<Employee> findEmployeesBySalaryGreaterThanEqual(double salary) {
		return employeeRepository.findBySalaryGreaterThanEqual(salary);
	}
	
	public Integer updateBaseLocation(int empId, String newBaseLocation) {
		return employeeRepository.updateBaseLocation(empId, newBaseLocation);
	}
	
	public List<Employee> findByLocationOrderByName(String baseLocation) {
		return employeeRepository.findByBaseLocationOrderByEmpNameDesc(baseLocation);
	}
	
	public List<Employee> findByBaseLocationAndDesignation(String baseLocation, String designation) {
		return employeeRepository.findByBaseLocationAndDesignation(baseLocation, designation);
	}
	
	public List<Employee> findEmployeesBySalaryBetween(double lowerLimit, double upperLimit) {
		return employeeRepository.findBySalaryBetween(lowerLimit, upperLimit);
	}
	
}
