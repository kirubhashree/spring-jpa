package com.damodar.spring.SpringDataJPA2.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.damodar.spring.SpringDataJPA2.entity.Employee;

@EnableJpaRepositories
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

	@Query(value = "SELECT e FROM Employee e WHERE e.empName LIKE %:pattern%")
	List<Employee> findByNameLike(@Param("pattern") String pattern);

	@Query(value = "SELECT e FROM Employee e WHERE e.empSalary >= :salary")
	List<Employee> findBySalaryGreaterThanEqual(@Param("salary") double salary);

    @Modifying
    @Transactional
    @Query(value = "UPDATE Employee e SET e.baseLocation = :newBaseLocation WHERE e.empId = :empId")
    Integer updateBaseLocation(@Param("empId") int empId,@Param("newBaseLocation") String newBaseLocation);

    @Query(value = "SELECT e FROM Employee e WHERE e.empSalary BETWEEN :lowerLimit AND :upperLimit")
    List<Employee> findBySalaryBetween(@Param("lowerLimit") double lowerLimit,@Param("upperLimit") double upperLimit);

    List<Employee> findByBaseLocationOrderByEmpNameDesc(String baseLocation);

    List<Employee> findByBaseLocationAndDesignation(String baseLocation, String designation);
}
