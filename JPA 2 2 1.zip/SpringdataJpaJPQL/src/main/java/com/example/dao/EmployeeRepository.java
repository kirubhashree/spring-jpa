package com.example.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.entity.Employee;

import jakarta.transaction.Transactional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	
	@Query("SELECT e FROM Employee e WHERE e.empName LIKE :pattern")
	List<Employee> findByNameLike(String pattern);
	
	@Query("SELECT e FROM Employee e WHERE e.empSalary >= :salary")
	List<Employee> findBySalaryGreaterThanEqual(double salary);
	
	@Modifying
	@Transactional
	@Query("UPDATE Employee e SET e.baseLocation = :newBaseLocation WHERE e.empId = :empId")
	Integer updateBaseLocation(int empId, String newBaseLocation);
	
	@Query("SELECT e FROM Employee e WHERE e.empSalary BETWEEN :lowerLimit AND :upperLimit")
	List<Employee> findBySalaryBetween(double lowerLimit, double upperLimit);
	
	List<Employee> findByBaseLocationOrderByEmpNameDesc(String baseLocation);
	List<Employee> findByBaseLocationAndDesignation(String baseLocation, String designation);
}
