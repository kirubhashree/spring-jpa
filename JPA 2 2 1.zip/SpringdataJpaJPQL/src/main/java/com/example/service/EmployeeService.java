package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.EmployeeRepository;
import com.example.entity.Employee;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;
	
	public int saveEmployee(Employee emp) {
		int empId=0;
		empId = employeeRepository.save(emp).getEmpId();
		return empId;
	}
	
	public List<Employee> findEmployeesByNameLike(String pattern){
		return employeeRepository.findByNameLike(pattern);
	}
	
	public List<Employee> findEmployeesBySalaryGreaterThanEqual(double salary){
		return employeeRepository.findBySalaryGreaterThanEqual(salary);
	}
	
	public Integer updateBaseLocation(int empId, String newBaseLocation) {
		return employeeRepository.updateBaseLocation(empId, newBaseLocation);
	}
	
	public List<Employee> findByLocationOrderByName(String baseLocation){
		return employeeRepository.findByBaseLocationOrderByEmpNameDesc(baseLocation);
	}
	
	public List<Employee> findByBaseLocationAndDesignation(String baseLocation, String designation){
		return employeeRepository.findByBaseLocationAndDesignation(baseLocation, designation);
	}
	
	public List<Employee> findEmployeesBySalaryBetween(double lowerLimit, double upperLimit){
		return employeeRepository.findBySalaryBetween(lowerLimit, upperLimit);
	}
}
