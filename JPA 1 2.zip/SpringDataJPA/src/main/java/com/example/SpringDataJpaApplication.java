package com.example;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.example.model.Customer;
import com.example.service.CustomerService;



@SpringBootApplication
@ComponentScan("com.example")
public class SpringDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaApplication.class, args);
	}
	@Bean
	public CommandLineRunner demo(CustomerService service) {
		return (args) -> {
			
			service.saveCustomer(new Customer("Jack", "8234567890", "Pune"));
			service.saveCustomer(new Customer("Sonu", "9934565590", "Chennai"));
			service.saveCustomer(new Customer("Mitali", "7134567890", "Bangalore"));
			
			
			System.out.println("Updated Customer:");
			System.out.println(service.updateCustomer(3, "9534567890"));
			
			
			System.out.println(service.findAllCustomers());
			
			
			service.deleteCustomer(3);
		};
	}}
