package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.CustomerRepository;
import com.example.model.Customer;



@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	public int saveCustomer(Customer customer) {
		int customerId=0;
		customerId = customerRepository.save(customer).getCustomerId();
		return customerId;
	}
	
	public List<Customer> findAllCustomers() {
		return customerRepository.findAll();
	}
	
	public Optional<Customer> updateCustomer(int customerId, String newMobileNumber){
		Optional<Customer> custOptional = customerRepository.findById(customerId);
		if(custOptional.isPresent()) {
			Customer customer = custOptional.get();
			customer.setMobileNumber(newMobileNumber);
			
			customerRepository.save(customer);
			return Optional.of(customer);
		}
		return custOptional;
	}
	
	public void deleteCustomer(int customerId) {
		customerRepository.deleteById(customerId);
		
	}

}
